# Project Files: Dependency Injection with Factory

Use the files in the **starter** folder to follow the [Dependency Injection with Factory](https://peterfriese.github.io/MakeItSo/tutorials/makeitso) tutorial. To explore on your own, open the Xcode project in the **final** folder and browse the project's code.
