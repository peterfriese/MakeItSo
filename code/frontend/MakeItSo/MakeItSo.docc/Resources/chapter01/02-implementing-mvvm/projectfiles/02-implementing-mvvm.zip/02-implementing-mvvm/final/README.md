# Implementing Model, View, ViewModel (MVVM) - Final

This folder contains the _final_ state for the _Implementing Model, View, ViewModel (MVVM)_ part of the _Make It So_ tutorial.