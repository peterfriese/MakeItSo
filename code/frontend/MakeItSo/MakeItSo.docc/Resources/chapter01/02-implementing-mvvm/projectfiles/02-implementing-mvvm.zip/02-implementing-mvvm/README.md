# Project Files: Implementing Model, View, ViewModel (MVVM)

Use the files in the **starter** folder to follow the [Implementing Model, View, ViewModel (MVVM)](https://peterfriese.github.io/MakeItSo/tutorials/makeitso) tutorial, you'll create a new Xcode project as described in the first section of the tutorial. To explore on your own, open the Xcode project in the **final** folder and browse the project's code.
