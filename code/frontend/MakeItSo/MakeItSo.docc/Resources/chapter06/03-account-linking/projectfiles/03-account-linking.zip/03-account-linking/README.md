# Project Files: Account Linking

Use the files in the **starter** folder to follow the [Account Linking](https://peterfriese.github.io/MakeItSo/tutorials/makeitso) tutorial. To explore on your own, open the Xcode project in the **final** folder and browse the project's code.
