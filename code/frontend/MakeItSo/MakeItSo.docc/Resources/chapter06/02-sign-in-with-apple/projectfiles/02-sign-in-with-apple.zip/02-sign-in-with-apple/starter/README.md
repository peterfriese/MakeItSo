# Sign in with Apple and Firebase Authentication - Starter

This folder contains the _starter_ project for the _Sign in with Apple and Firebase Authentication_ part of the _Make It So_ tutorial.