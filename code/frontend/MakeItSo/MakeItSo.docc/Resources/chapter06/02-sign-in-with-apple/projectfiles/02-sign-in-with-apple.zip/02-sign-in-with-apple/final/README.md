# Sign in with Apple and Firebase Authentication - Final

This folder contains the _final_ state for the _Sign in with Apple and Firebase Authentication_ part of the _Make It So_ tutorial.