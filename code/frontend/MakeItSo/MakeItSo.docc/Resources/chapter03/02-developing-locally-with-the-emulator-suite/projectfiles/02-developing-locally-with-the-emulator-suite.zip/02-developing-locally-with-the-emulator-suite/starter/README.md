# Developing locally with the Emulator Suite - Starter

This folder contains the _starter_ project for the _Developing locally with the Emulator Suite_ part of the _Make It So_ tutorial.