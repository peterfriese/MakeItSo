# Updating data in Cloud Firestore - Final

This folder contains the _final_ state for the _Updating data in Cloud Firestore_ part of the _Make It So_ tutorial.