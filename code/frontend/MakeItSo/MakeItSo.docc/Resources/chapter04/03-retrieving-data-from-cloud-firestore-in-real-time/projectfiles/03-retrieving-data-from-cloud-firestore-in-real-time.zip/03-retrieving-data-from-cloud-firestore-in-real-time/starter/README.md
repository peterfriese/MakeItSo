# Retrieving data from Cloud Firestore in real-time - Starter

This folder contains the _starter_ project for the _Retrieving data from Cloud Firestore in real-time_ part of the _Make It So_ tutorial.