# Storing data in Cloud Firestore - Starter

This folder contains the _starter_ project for the _Storing data in Cloud Firestore_ part of the _Make It So_ tutorial.