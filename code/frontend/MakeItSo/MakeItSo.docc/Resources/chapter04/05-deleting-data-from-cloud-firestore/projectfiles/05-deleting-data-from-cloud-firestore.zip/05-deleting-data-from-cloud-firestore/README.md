# Project Files: Deleting data from Cloud Firestore

Use the files in the **starter** folder to follow the [Deleting data from Cloud Firestore](https://peterfriese.github.io/MakeItSo/tutorials/makeitso) tutorial. To explore on your own, open the Xcode project in the **final** folder and browse the project's code.
