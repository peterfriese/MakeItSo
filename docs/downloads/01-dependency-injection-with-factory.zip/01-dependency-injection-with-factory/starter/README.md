# Dependency Injection with Factory - Starter

This folder contains the _starter_ project for the _Dependency Injection with Factory_ part of the _Make It So_ tutorial.