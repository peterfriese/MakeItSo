# Retrieving data from Cloud Firestore in real-time - Final

This folder contains the _final_ state for the _Retrieving data from Cloud Firestore in real-time_ part of the _Make It So_ tutorial.