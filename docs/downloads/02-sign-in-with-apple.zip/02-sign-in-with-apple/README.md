# Project Files: Sign in with Apple and Firebase Authentication

Use the files in the **starter** folder to follow the [Sign in with Apple and Firebase Authentication](https://peterfriese.github.io/MakeItSo/tutorials/makeitso) tutorial. To explore on your own, open the Xcode project in the **final** folder and browse the project's code.
