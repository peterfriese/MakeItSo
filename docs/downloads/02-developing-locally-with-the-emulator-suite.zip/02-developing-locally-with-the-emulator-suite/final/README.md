# Developing locally with the Emulator Suite - Final

This folder contains the _final_ state for the _Developing locally with the Emulator Suite_ part of the _Make It So_ tutorial.