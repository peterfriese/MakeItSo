# Building a Simple Todo List UI - Starter

This folder contains the starter files for the _Building a Simple Todo List UI_ part of the _Make It So_ tutorial.

The folder is intentionally empty - you will start out in a completely empty folder after all!