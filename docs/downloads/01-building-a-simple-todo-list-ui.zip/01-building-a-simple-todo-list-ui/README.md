# Project Files: Building a Simple Todo List UI

To follow the [Building a Simple Todo List UI](https://peterfriese.github.io/MakeItSo/tutorials/makeitso/building-a-simple-todo-list-ui) tutorial, you'll create a new Xcode project as described in the first section of the tutorial. To explore on your own, open the Xcode project in the **final** folder and browse the project's code.
