# Extracting the Reminder Row Into a Separate View - Final

This folder contains the _final_ state for the _Extracting the Reminder Row Into a Separate View_ part of the _Make It So_ tutorial.